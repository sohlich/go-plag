#include "hashtable.h"
#include <string.h>
#include "myMalloc.h"

unsigned int hash(HashTable *table, const Variant *key)
{
	//return 0;
	int delka, pos, vysledek=0;
	unsigned char *uk=(unsigned char*)key->data;
	switch (key->type) {
	case vtSTRING: {
		delka=strlen(key->data->datastring);
		break;
	}
	case vtDOUBLE: {
		delka=sizeof(double);
		break;
	}
	case vtCHAR: {
		return key->data->datachar % table->size;
		break;
	}
	case vtLONG: {
		return key->data->datalong % table->size;
		break;
	}
	case vtBOOL: {
		return key->data->databool;
		break;
	}
	}
	for(pos=0; pos<delka; pos++)
		vysledek+=ror(uk[pos], pos);
	return vysledek % table->size;
}

unsigned int ror(unsigned int value, size_t shift)
{
#define CHAR_BITS 8
	shift &= CHAR_BITS - 1; //shift bude v rozsahu 0 az 31 (pro 32-bit
	if (shift == 0) return value;
	return (value >> shift) | (value << (CHAR_BITS - shift));
}

////////////////////////////////////////////////////////////////////////////////
// operace nad tabulkou

void hashtable_init(HashTable *table, size_t size, bool deletecontents)
{
	int i;
	table->size=size;
	table->delete_contents=deletecontents;
	table->array=myMalloc(size*sizeof(HashTableNode*));
	for(i=0; i<size; i++) table->array[i]=NULL;
}

void hashtable_destruct(HashTable *table)
{
	table->size=0;
	myFree(table->array);
}

bool hashtable_insert(HashTable *table, Variant *key, Variant *value)
{
	int index=hash(table, key);
	if(hashtable_find(table, key)==NULL) {
		printf("hash: Klic: ");
		variant_print_val(key);
		printf(" -> Hash index: %d\n", index);
		HashTableNode *novy, *first=table->array[index];
		novy=myMalloc(sizeof(HashTableNode));
		novy->key=key;
		novy->value=value;
		novy->next=first;
		table->array[index]=novy;
		printf("cetnost slova ");
		variant_print_val(key);
		printf(" je: ");
		variant_print_val(value);
		printf("\n");
		return true;
	} else {

		HashTableNode *uk=table->array[index];
		while(uk!=NULL && variant_compare(uk->key, key)!=0)
			uk=uk->next;

		long old_value = uk->value->data->datalong;
		variant_free(uk->value);		
		uk->value = variant_new_long(old_value + 1);

		printf("cetnost slova ");
		variant_print_val(key);
		printf(" je: ");
		variant_print_val(uk->value);
		printf("\n");

		/*HashTableNode *uk = table->array[index];
		long oldvalue = uk->value->data->datalong;
		hashtable_delete(table, key);
		return hashtable_insert(table, key, variant_new_long(oldvalue + 1));*/
	}
}

bool hashtable_delete(HashTable *table, const Variant *key)
{
	int index=hash(table, key);
	HashTableNode *uk_pred=NULL, *uk=table->array[index];
	while(uk!=NULL && variant_compare(uk->key, key)!=0) {
		uk_pred=uk;
		uk=uk->next;
	}
	if(uk==NULL) return false;
	else if(uk_pred==NULL)
		table->array[index]=uk->next;//delete_first
	else
		uk_pred->next=uk->next;//delete_next
	if(table->delete_contents) {
		myFree(uk->value->data);
		myFree(uk->value);
		myFree(uk->key->data);
		myFree(uk->key);
	}
	myFree(uk);
	return true;
}

Variant* hashtable_find(HashTable *table, const Variant *key)
{
	int index=hash(table, key);
	HashTableNode *uk=table->array[index];
	while(uk!=NULL && variant_compare(uk->key, key)!=0)
		uk=uk->next;
	if(uk==NULL) return NULL;
	return uk->value;
}

size_t hashtable_get_count(const HashTable *table)
{
	int i;
	int pocet=0;
	HashTableNode *uk;
	for(i=0; i<table->size; i++) {
		uk=table->array[i];
		while(uk!=NULL) {
			uk=uk->next;
			pocet++;
		}
	}
	return pocet;
}

void hashtable_clear(HashTable *table)
{
	int i;
	HashTableNode *uk, *mazany;
	for(i=0; i<table->size; i++) {
		uk=table->array[i];
		table->array[i]=NULL;
		while(uk!=NULL) {
			mazany=uk;
			uk=uk->next;
			if(table->delete_contents) {
				if (mazany->value->type== vtSTRING) {
					myFree(mazany->value->data->datastring);
				}
				//myFree(mazany->value->data->datastring);
				myFree(mazany->value->data);
				myFree(mazany->value);
				myFree(mazany->key->data);
				myFree(mazany->key);
			}
			myFree(mazany);
		}
	}
}

void hashtable_process(HashTable *table, TableNodeProc proc )
{
	int i;
	HashTableNode *uk;
	for(i=0; i<table->size; i++) {
		uk=table->array[i];
		while(uk!=NULL) {
			proc(uk->key, uk->value);
			uk=uk->next;
		}
	}
}
