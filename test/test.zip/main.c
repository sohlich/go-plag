#include <stdio.h>
#include "hashtable.h"
#include "ioutils.h"
#include "mymalloc.h"


void menu (void)
{
	printf("\n1 - pridat slovo()\n"
	       "M - zobraz toto menu\n"
	       "K - konec\n"
	       "Pro ukonceni stiskni CTRL+D (Linux) nebo CTRL+Z (Windows).\n");
}

int main()
{
	char buffer[256];
	HashTable* tabulka = malloc(sizeof(HashTable));
	char volba;

	hashtable_init(tabulka, 1, 1);

	menu();
	do {
		volba=ioutils_get_char(buffer);
		switch(volba) {
		case '1': //přidat slovo

			printf("\nZadejte slovo:\n");
			char* slovo = ioutils_get_line(buffer);

			hashtable_insert(
			    tabulka,
			    variant_new_string(slovo),
			    variant_new_long(1));

			printf("Slovo bylo pridano.\n");
			break;

		case 'M':
			menu();
			break;

		case 'K':
			printf("Konec.\n");
			hashtable_destruct(tabulka);

			break;


		}
	} while(volba!='K');


	myFree(tabulka);
	return 0;
}
