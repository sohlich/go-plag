#ifndef IOUTILS_H_
#define IOUTILS_H_
#include <stdbool.h>

/*
 * Funkce, ktera vrati retezec (jeden radek vstupu)...
 * Pokud fce bude pracovat s jednim blokem v alokovane pameti, nemuzeme ji volat z vice vlaken!
 * Tzn, ze pri kazdem volani si budeme muset primo alokovat pamet.
 * 
 * Proto do parametru umistime predinicializovany buffer. Fce je tedy "thread-save"
 */
char * ioutils_get_line(char buffer[]);
char ioutils_get_char(char buffer[]);
int ioutils_get_int(char buffer[]);
bool ioutils_get_bool(char buffer[]);
//long ioutils_get_long(char buffer[]);
long ioutils_get_long(char buffer[], bool printWarning);
double ioutils_get_double(char buffer[]);

#endif /* IOUTILS_H_ */