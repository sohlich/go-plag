#include "variant.h"
#include <string.h>
#include "mymalloc.h"
#include "ioutils.h"
////////////////////////////////////////////////////////////////////////////////
///
/// \brief - dokumentace se generuje v DOXYGEN
///

#define POLE_MAX_SIZE  256


/*!
 * \brief Vytvoří novou proměnnou Variant zadaného typu
 * \param type Typ proměnné Variant
 */
Variant * variant_get_new(VariantType type)
{

	char buffer[POLE_MAX_SIZE];
	char c;
	Variant* v;

	switch (type) {
	case vtBOOL:
		printf("Vlozte hodnoty 1=true, 0=false oddelene novym radkem. 'K'=konec:\n");
		//v = variant_new_bool(ioutils_get_bool(buffer));
		do {
			c = ioutils_get_char(buffer);
			switch(c) {
			case '1':
				v = variant_new_bool(true);
				break;
			case '0':
				v = variant_new_bool(false);
				break;
			}
		} while (c!='K');
		break;
	case vtCHAR:
		printf("Vlozte znaky, oddelene novym radkem. '0'=konec:\n");
		//v = variant_new_char(ioutils_get_char(buffer));
		do {
			c = ioutils_get_char(buffer);
			if (c!='0') v = variant_new_char(c);
		} while (c!='0');
		break;
	case vtDOUBLE:
		printf("Vlozte hodnotu double:\n");
		v = variant_new_double(ioutils_get_double(buffer));
		break;
	case vtLONG:
		printf("Vlozte cisla long int oddelene novym radkem. 'K'=konec:\n");
		v = variant_new_long(ioutils_get_long(buffer, true));
		break;
	case vtSTRING:
		printf("Vlozte retezec ukoncene novym radkem:\n");
		memset(buffer, 0, POLE_MAX_SIZE);
		v = variant_new_string(ioutils_get_line(buffer));
		break;

	}
	return v;
}

void variant_get_new_array(VariantType type,Variant** pole,char* buffer)
{


	long langos;
	char c;
	Variant* v;
	int i = 0;
	switch (type) {
	case vtBOOL:
		printf("Vlozte hodnoty 1=true, 0=false oddelene novym radkem. 'K'=konec:\n");
		//v = variant_new_bool(ioutils_get_bool(buffer));
		do {
			c = ioutils_get_char(buffer);
			if (c=='1') {
	//printf("TRUE");
				pole[i] = variant_new_bool(true);
				//printf("TRUE");
				i++;
			}
		//	else if (c=='0') {
		//		pole[i] = variant_new_bool(false);
				//printf("FALSE");
		//		i++;
		//	}
			else if (c!='K') {
				pole[i] = variant_new_bool(false);
				//printf("FALSE");
				i++;
			}
				
		} while (c!='K' && i<POLE_MAX_SIZE);
		//printf("VYSKOC1 i=%f p=%f", &i, POLE_MAX_SIZE);
		break;
	case vtCHAR:
		printf("Vlozte znaky, oddelene novym radkem. 'K'=konec:\n");
		//v = variant_new_char(ioutils_get_char(buffer));
		do {
			c = ioutils_get_char(buffer);
			if (c!='K') {
				pole[i]= variant_new_char(c);
				i++;
			}
		} while (c!='K' && i<POLE_MAX_SIZE);
		break;
	case vtDOUBLE:
		printf("Vlozte hodnotu double:");
		v = variant_new_double(ioutils_get_double(buffer));
		break;
	case vtLONG:
		printf("Vlozte cisla long int oddelene novym radkem. 'K'=konec:\n");
		//v = variant_new_long(ioutils_get_long(buffer));
		do {
			ioutils_get_line(buffer);
			c = buffer[0];
			if (c!='K' && (sscanf(buffer, "%ld", &langos) > 0)) {
				pole[i]= variant_new_long(langos);
				i++;
			}
		} while (c!='K' && i<POLE_MAX_SIZE);
		break;
	case vtSTRING:
		printf("Vlozte retezce, oddelene novym radkem. 'K'=konec:\n");
		char* radek;
		do {
			radek = ioutils_get_line(buffer);
			if (radek[0]!='K' ) {
				pole[i]= variant_new_string(radek);
				i++;
			}
		} while (radek[0]!='K' && i<POLE_MAX_SIZE);
		break;

	}
		//printf("VYSKOC2");
}


/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu bool
 * \param val Hodnota typu bool
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_bool(bool val)
{
	Variant * v = myMalloc(sizeof(Variant));
	v->type=vtBOOL;
	v->data= myMalloc(sizeof(bool));
	v->data->databool = val;
	return v;
}
/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu char
 * \param val Hodnota typu char
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_char(char val)
{
	Variant * v = myMalloc(sizeof(Variant));
	v->type=vtCHAR;
	v->data= myMalloc(sizeof(char));
	v->data->datachar = val;
	return v;
}

/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu long
 * \param val Hodnota typu long
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_long(long val)
{
	Variant * v = myMalloc(sizeof(Variant));
	v->type=vtLONG;
	v->data= myMalloc(sizeof(long));
	v->data->datalong = val;
	return v;
}



/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu double
 * \param val Hodnota typu double
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_double(double val)
{
	Variant * v = myMalloc(sizeof(Variant));
	v->type=vtDOUBLE;
	v->data= myMalloc(sizeof(double));
	v->data->datadouble = val;
	return v;
}
/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu string
 * \param val Hodnota typu string
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_string(const char* val)
{
	Variant * v = myMalloc(sizeof(Variant));
	v->type=vtSTRING;
	v->data= myMalloc(sizeof(VariantUnion));
	v->data->datastring= myMalloc((strlen(val)+1)*sizeof(char));
	strcpy(v->data->datastring,val);
	return v;
}

////////////////////////////////////////////////////////////////////////////////

/*!
 * \brief Uvolneni pameti alokovane pro objekt typu Variant
 * \param v Ukazatel na objekt typu Variant
 */
void variant_free(Variant *v)
{
	if(v!=NULL) {
		if (v->type== vtSTRING) myFree(v->data->datastring);
		myFree(v->data);
		myFree(v);
	}
}
/*!
 * \brief Uvolneni pole hodnot datoveho typu Variant
 * \param v Ukazatel na pocatek pole hodnot typu Variant
 * \param n Pocet prvku v poli
 */
void variant_free_array(Variant **v, size_t n)
{
	int i;
	for (i=0; i<n; i++) {
		variant_free(v[i]);
		v[i]=NULL; // uklidit
	}
}

////////////////////////////////////////////////////////////////////////////////

/*!
 * \brief Tisk hodnoty typu Variant
 * \param v Ukazatel na objekt typu Variant
 */
void variant_print_val(Variant *v)
{
	if (v!=NULL)
		switch (v->type) {
		case vtBOOL:
			printf("%s", v->data->databool?"TRUE":"FALSE");
			break;
		case vtCHAR:
			printf("%c", v->data->datachar);
			break;
		case vtDOUBLE:
			printf("%lf", v->data->datadouble);
			break;
		case vtLONG:
			printf("%ld", v->data->datalong);
			break;
		case vtSTRING:
			printf("%s", (char*)v->data->datastring);
			break;
		}
	else printf("NULL"); //
}
/*!
 * \brief Tisk vsech hodnot typu Variant v danem poli
 * \param v Ukazatel na pocatek pole hodnot typu Variant
 * \param n Pocet prvku v poli
 */
void variant_print_val_array(Variant **v, size_t n)
{
	int i;
	for (i=0; i<n; i++) {
		if (v[i]!=NULL) { // ignoruj smazane
			variant_print_val(v[i]);
			printf(" "); // aspon trochu oddelit
		};
	}
}
/*!
 * \brief Tisk datoveho typu kontejneru Variant
 * \param v Ukazatel na objekt typu Variant
 */
void variant_print_type(Variant *v)
{
	switch (v->type) {
	case vtBOOL:
		printf("<BOOL>");
		break;
	case vtCHAR:
		printf("<CHAR>");
		break;
	case vtDOUBLE:
		printf("<DOULE>");
		break;
	case vtLONG:
		printf("<LONG>");
		break;
	case vtSTRING:
		printf("<STRING>");
		break;
	}

}

////////////////////////////////////////////////////////////////////////////////

/*!
 * \brief Srovnani dvou hodnot typu Variant
 * \param v1 Ukazatel na objekt typu Variant
 * \param v2 Ukazatel na objekt typu Variant
 * \return Funkce vraci zapornou hodnotu je-li v1 < v2, kladnou hodnotu je-li
 * v1 > v2 a nulovou hodnotu je-li v1 == v2
 */
int variant_compare(Variant* v1, Variant* v2)
{
	//osetri NULL hodnoty
	if (v1==NULL &&  v2!=NULL) return -1;
	if (v1!=NULL &&  v2==NULL) return 1;
	if (v1==NULL && v2==NULL) return 0;

	//nejsou NULL, jestli nemaji stejny typ, tak to nejde porovnavat
	if (v1->type!=v2->type) {
		printf("Porovnavane Varianty nemaji stejny typ. Nelze je setridit. exit\n");
		return 0;
	};
	//jsou stejne, tak pokracuj
	switch (v1->type) {
	case vtBOOL:
		return v1->data->databool - v2->data->databool;
		break;
	case vtCHAR:
		return v1->data->datachar - v2->data->datachar;
		break;
	case vtDOUBLE:
		return v1->data->datadouble - v2->data->datadouble;
		break;
	case vtLONG:
				return v1->data->datalong - v2->data->datalong;
		break;
	case vtSTRING:
		return strcmp(v1->data->datastring,v2->data->datastring);
		break;
	}
	return 0;
}

int compare (const void* a, const void* b)
{
	return variant_compare(*(Variant**)a,*(Variant**)b);
}
/*!
 * \brief Razeni pole hodnot typu Variant dle jejich obsahu
 * \param varray Ukazatel na pocatek pole hodnot typu Variant
 * \param n Pocet prvku pole
 */
void variant_sort(Variant **varray, size_t n)
{
	qsort(varray,n,sizeof(Variant*),compare);
}


/*!
 * \brief Vypíše menu s dotazem na typ variant, který chcete použít
 * \return Typ variantu nebo -1
 */
VariantType variant_input_menu()
{
	char buffer[256];
	char volba;
	do {
		printf("Jaky typ Variant chcete pouzit?\n");
		printf("1: variant bool\n");
		printf("2: variant char\n");
		printf("3: variant long\n");
		printf("4: variant double\n");
		printf("5: variant string\n");
//printf("CHYBA");
		volba = ioutils_get_char(buffer);
		switch (volba) {
		case '1':
			return vtBOOL;
			
			//break;
		case '2':
			return vtCHAR;
			//break;
		case '3':
			return vtLONG;
			//break;
		case '4':
			return vtDOUBLE;
			//break;
		case '5':
			return vtSTRING;

			//break;
		}
	} while (1);
}
