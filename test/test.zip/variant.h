#ifndef _VARIANT_H_
#define _VARIANT_H_

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <ioutils.h>

////////////////////////////////////////////////////////////////////////////////

/*!
 * \brief Zakladni datove typy podporovane univerzalnim datovym typem Variant 
 */
typedef enum _VariantType
{
	vtBOOL,
	vtCHAR,
	vtLONG,
	vtDOUBLE,
	vtSTRING
} VariantType;

typedef union _VariantUnion {
	bool databool;
	char datachar;
	char* datastring;
	long datalong;
	double datadouble;
} VariantUnion;

/*!
 * \brief Definice datoveho typu Variant 
 */
//typedef unsigned char uint8;

typedef struct _Variant
{
	VariantType type;
	VariantUnion * data;
	//void * data;					// vyberte si, zda chcete ukazatel na union Variant nebo na netypový ukazatel (void*)
} Variant;

typedef struct _DynamickePole
{
	Variant** pole;
} DynamickePole;

////////////////////////////////////////////////////////////////////////////////

void variant_get_new_array(VariantType type,Variant** pole,char* buffer);


/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu bool
 * \param val Hodnota typu bool
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_bool(bool val);
/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu char
 * \param val Hodnota typu char
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_char(char val);
/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu long
 * \param val Hodnota typu long
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_long(long val);
/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu double
 * \param val Hodnota typu double
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_double(double val);
/*!
 * \brief Vytvoreni datoveho typu Variant s hodnotou typu string
 * \param val Hodnota typu string
 * \return Ukazatel na novy objekt datoveho typu Variant
 */
Variant* variant_new_string(const char* val);

////////////////////////////////////////////////////////////////////////////////

/*!
 * \brief Uvolneni pameti alokovane pro objekt typu Variant
 * \param v Ukazatel na objekt typu Variant
 */
void variant_free(Variant *v);
/*!
 * \brief Uvolneni pole hodnot datoveho typu Variant
 * \param v Ukazatel na pocatek pole hodnot typu Variant
 * \param n Pocet prvku v poli
 */
void variant_free_array(Variant **v, size_t n);

////////////////////////////////////////////////////////////////////////////////

/*!
 * \brief Tisk hodnoty typu Variant
 * \param v Ukazatel na objekt typu Variant
 */
void variant_print_val(Variant *v);
/*!
 * \brief Tisk vsech hodnot typu Variant v danem poli
 * \param v Ukazatel na pocatek pole hodnot typu Variant
 * \param n Pocet prvku v poli 
 */
void variant_print_val_array(Variant **v, size_t n);
/*!
 * \brief Tisk datoveho typu kontejneru Variant
 * \param v Ukazatel na objekt typu Variant
 */
void variant_print_type(Variant *v);

////////////////////////////////////////////////////////////////////////////////

/*!
 * \brief Srovnani dvou hodnot typu Variant
 * \param v1 Ukazatel na objekt typu Variant
 * \param v2 Ukazatel na objekt typu Variant
 * \return Funkce vraci zapornou hodnotu je-li v1 < v2, kladnou hodnotu je-li
 * v1 > v2 a nulovou hodnotu je-li v1 == v2
 */
int variant_compare(Variant *v1, Variant* v2);
/*!
 * \brief Razeni pole hodnot typu Variant dle jejich obsahu
 * \param varray Ukazatel na pocatek pole hodnot typu Variant
 * \param n Pocet prvku pole
 */
void variant_sort(Variant **varray, size_t n);

////////////////////////////////////////////////////////////////////////////////
//				Nepovinne utility funkce
////////////////////////////////////////////////////////////////////////////////
/*!
 * \brief Vytvoří novou proměnnou Variant zadaného typu
 * \param type Typ proměnné Variant
 */
Variant * variant_get_new(VariantType type);



/*!
 * \brief Naplní pole proměnnými Variant, které vytvoří a jejich hodnoty přečte ze stdin
 * \param arr Pole
 * \param n Počet prvků pole, které je potřeba naplnit.
 */
int variant_get_new_arr(Variant ** arr, size_t n);

/*!
 * \brief Vypíše menu s dotazem na typ variant, který chcete použít
 * \return Typ variantu
 */
VariantType variant_input_menu();

#endif //_VARIANT_H_
