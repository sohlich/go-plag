#include "ioutils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAX_LEN 256

int ch;
/*
 * Pokud budu chtit zviditelnit nejakou promenou, oznacim ji jako extern
 */

char * ioutils_get_line(char buffer[MAX_LEN])
{
		//printf("get_line\n"); //
	memset(&buffer[0], 0, MAX_LEN);
	int i=0;

	while (i<MAX_LEN)
	{
		if ((ch=getchar()))
		{
			//printf("read_char\n"); //
			if (ch != '\n' && ch != EOF)
			{
				//printf("char_ok\n"); //
				buffer[i]=ch;
				i++;		
			}
			else
			{
				
				if (i==0 && ch == EOF)
				{
					printf("Neocekavany konec souboru\n"); 
					exit(EXIT_SUCCESS);		
				}
				break;
			}
		}
		else
		{
			fprintf(stderr, "Nepodarilo se nacist znak");
			exit(EXIT_FAILURE);	
		}
	}
	//Pokud uzivatel zada vice jak MAX_LEN znaku
	if (buffer[i] != '\n' && i>= MAX_LEN)
	{
		//printf("cyklim");//
		while (getchar() != '\n');
	}
		//printf("get_line_succes\n"); //
	return buffer;
/*
 * Alternativni zpusoby
 *
 * Pokud uzivatel zada vice jak 256, nastane stackoverflow
 * vrati nulu, pokud se nepodari nacist zadny znak, jeden pokud jeden atd...
 * pokud vrati -1, konec souboru
 *
	if (scanf("%s", buffer)<0)
	{
		fprintf(stderr, "Neocekavany konec souboru");
		exit(EXIT_FAILURE);
	}
 */
}

char ioutils_get_char(char buffer[])
{
	//printf("get_char\n"); //
	ioutils_get_line(buffer);
	return buffer[0];
}
bool ioutils_get_bool(char buffer[]) {
	ioutils_get_char(buffer);
	return (buffer[0]=='t' ||buffer[0]=='1')?true:false;
}

int ioutils_get_int(char buffer[MAX_LEN])
{
	int result = 0;

	do
	{
		ioutils_get_line(buffer);
		if (sscanf(buffer, "%d", &result) > 0)
		{
			break;
		}
		else
		{
			printf("Nespravny format, zkuste znovu\n");
		}
	}
	while (1);
	return result;

	// buffer
	// ukazatel na znak (ukazuje na prvni spatny znak
	// format cisla (desitkove)
	// strtol(buffer, &err, 10);
}
long ioutils_get_long(char buffer[MAX_LEN], bool printWarning) {
		long result = 0;

	do {
		ioutils_get_line(buffer);
		if (sscanf(buffer, "%ld", &result) > 0) {
			break;
		} else if (printWarning) {
			printf("Nespravny format, zkuste znovu\n");
		}
		
	} while (1);
	
	return result;
}
//////////////////////////////////	
//long ioutils_get_long(char buffer[MAX_LEN]) {
//
//	return ioutils_get_long(buffer, true);
//}


double ioutils_get_double(char buffer[MAX_LEN]) {
	double result = 0;

	do {
		ioutils_get_line(buffer);
		if (sscanf(buffer, "%lf", &result) > 0) {
			break;
		} else {
			printf("Nespravny format, zkuste znovu\n");
		}
	} while (1);
	
	return result;
}
