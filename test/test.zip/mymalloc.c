#include "mymalloc.h"
#include <stdio.h>
/**
 * \file mymalloc.c
 * \brief Modul mymalloc obsahuje funkce pro ladìní pridělování paměti
 *
 * Podrobnější dokumentaci najdete v souboru mymalloc.h.
 */

/* Pozn.: vnitřnosti modulu mymalloc záměrně nejsou dokumentovány ve formátu
 * doxygen, aby zbytečně nezaplevelovaly výslednou dokumentaci a nemátly vás
 */
#define HASH_TABLE_SIZE 101 	/* počet položek pole hash, musí být prvočislo */
typedef void * tHTableKey; /* typ vyhledávacího klíče = ukazatel */
typedef int tHTableData; /* typ dat uloženych pod hledanym klicem = velikost alokované pameti*/
typedef int tHTableIndex; /* index do vnitřního pole hash tabulky */
typedef unsigned long int tDword;
#define compEQ(a,b) (a == b)	/* funkce pro porovnani 2 klíčů */

typedef struct tHTableNode_s {
	tHTableKey key; /* vyhledávací klíč */
	tHTableData data; /* data */
	struct tHTableNode_s *next; /* next node */
} tHTableNode;

tHTableNode *hashTable[HASH_TABLE_SIZE]; /* jednoduchá hashovaci tabulka=pole ukazatelu na uzel */

/***************************************************************************
 *  funkce hash převádí klíč na index do pole hash tabulky
 ***************************************************************************/
tHTableIndex hashFn(tHTableKey key) {
	return ((tDword) key % HASH_TABLE_SIZE);
}

/***************************************************************************
 * funkce insertHTableNode vytvoří nový uzel se zadaným klíčem a daty a vloží jej
 * do tabulky na první místo lin. seznamu synonym
 ***************************************************************************/
tHTableNode * insertHTableNode(tHTableKey key, tHTableData data) {
	tHTableNode *ptrFirst, *ukTmp;
	tHTableIndex index;

	index = hashFn(key); /* hash fce vrátí index do pole hash tab. */
	/* nyní vytvoříme v dyn. paměti nový uzel */
	if ((ptrFirst = malloc(sizeof(tHTableNode))) == NULL) {
		fprintf(stderr, "out of memory (insertHTableNode)\n");
		exit(1); /* pokud se alokace nepodařila, konec */
	}
	/* Zde uděláme klasický InsertFirst jako v lineárním seznamu */

	ukTmp = hashTable[index]; /* schováme si ukazatel na začátek seznamu synonym */
	hashTable[index] = ptrFirst; /* a přepíšeme jej ukazatelem na nový 1. uzel */
	ptrFirst->next = ukTmp; /* na nový první uzel navážeme starý 1. uzel */
	ptrFirst->key = key; /* a naplníme klíč a data hodnotami */
	ptrFirst->data = data;

	return ptrFirst;
}

/***************************************************************************
 * Funkce deleteNode smaže zadaný klíč z tabulky a vrátí jeho hodnotu.
 * Klíč je potřeba nejdřív najít v lin. seznamu synonym, nalezený uzel pak
 * smazat. Operace je ekvivalentní PostDelete v lineárním seznamu.
 ***************************************************************************/

tHTableData deleteNode(tHTableKey key) {
	tHTableNode *ukAct, *ukPrev = NULL;
	tHTableIndex index;
	tHTableData data;

	/* nejdříve spočítáme index, kde začíná lin. seznam synonym */
	index = hashFn(key);
	ukAct = hashTable[index];
	while (ukAct && !compEQ(ukAct->key, key)) {
		ukPrev = ukAct;
		ukAct = ukAct->next;
	}
	if (ukAct == NULL)
		return -1; //hledaný klíč nebyl nalezen

	if (ukPrev == NULL) /* mažeme první uzel seznamu synonym ? */
		hashTable[index] = ukAct->next; /* ano: nastav ukazatel na první prvek na další za mazaným */
	else
		/* ne: propoj prvek před mazaným s prvkem za mazaným */
		ukPrev->next = ukAct->next;

	data = ukAct->data;
	free(ukAct);
	return data;
}

/*******************************
 *  find node containing key  *
 *******************************/

tHTableData findNode(tHTableKey key) {
	tHTableNode *uk;

	uk = hashTable[hashFn(key)];
	while (uk && !compEQ(uk->key, key))
		uk = uk->next;
	return uk->data;
}

/****************************************************************************************
 * Funkce myMalloc
 * hash tabulka s jednoduchou hash funkci typu "modulo"
 *****************************************************************************************/

long int alokaceCelkem = 0;
void * myMalloc(long size) {
	void *tmpUk = malloc(size);
#ifdef DEBUG
	if (tmpUk != NULL) {
		insertHTableNode(tmpUk, size);
		alokaceCelkem += size;
		printf("myMalloc: +%ld bajtu, celkem prideleno: %ld bajtu\n",
				size, alokaceCelkem);
	}
#endif
	return tmpUk;
}

void myFree(void * memblock) {
#ifdef DEBUG
	long size = 0;
	if (memblock != NULL) {
		size = deleteNode(memblock);
		if (size < 0)
			printf(
					"myFree: error: ukazatel %p nebyl alokovan pomoci myMalloc()\n",
					memblock);
		else {
			alokaceCelkem -= size;
			printf("myFree: -%ld bajtu, celkem prideleno: %ld bajtu\n",
					size, alokaceCelkem);
		}
	}

#endif
	free(memblock);
}
